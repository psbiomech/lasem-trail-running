%%% DESCRIPTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% This code performs a data-tracking simulation of a full stride of human
% walking in three dimensions using OpenSim Moco software for direct 
% collocation.  The model is a modified version of Rajagopal et al. (2016).
% The tracking targets are average pelvis angles, lower limb joint angles, 
% and ground reaction forces from Miller et al. (2014) and average shoulder
% and elbow angles from Collins et al. (2009).  The trunk orientation is 
% determined by a "postural controller" of sorts that minimizes deviations 
% from zero in the global reference frame.  The simulation is constrained 
% to have periodic states and controls and a prescribed average speed.  
%
% The cost function is the weighted sum of (i) the mean squared deviation 
% from tracking targets, in multiples of the average between-subjects 
% standard deviations and (ii) the mean squared muscle excitation, 
% multiplied by a constant w.  The user provides the value of w.  The value
% given here as default (50.0) produced a reasonable gross metabolic cost
% of ~3.6 J/m/kg with reasonably good tracking accuracy.  The auxilliary 
% derivaties of the muscle contractile dynamics (here, dF/dt, where F is 
% the normalized tendon forces) are also added to the cost function.  This 
% term is just for optimization/convergence purposes and has very light 
% weighting so that it does not influence solutions much, although it could 
% be viewed as a "smoothness" criterion of sorts.
%
% The model has 31 degrees of freedom, identical to the definitions of 
% Rajagopal et al. (2016) except that the knee was converted to a pin joint 
% with no translations.  Patella motion is still coupled to knee flexion.  
% Contact elements were defined on the plantar surface of each foot beneath 
% the heel, the 1st, 3rd, and 5th metatarsal heads, and the distal 3rd and
% 5th phalanges.  
%
% The model has 84 muscles actuating the lower limb and lumbar joints.
% Lumbar muscles were added with geometry from Raabe & Chaudhari (2016).  
% A uniarticular toe flexor ("flexor digitorum brevis") was added using 
% data from Kura et al. (1997).  Muscle optimal fiber lengths were adjusted 
% so that the muscles produce their maximum isometric forces at the joint 
% angles identified for maximum isometric torque from Anderson et al. 
% (2007) and Keller & Roy (2002).  For biarticular muscles the average of 
% muscle lengths for max torque at both joints was used.  In cases where 
% this adjustment would have caused a reduction in optimal fiber length 
% when this length was already fairly short, the tendon slack length was 
% adjusted instead.  This approach resulted in gastrocnemius being unable 
% to produce much force in the stance phase of walking, so its optimal 
% fiber length was set to produce maximum force with -10� knee flexion and 
% 13� dorsiflexion (Hasson et al., 2011).  The shoulder and elbow joints
% are controlled by "cheap" torque generators (optimal force = 100 Nm).  
% The lumbar muscles are assisted by "costly" torque generators (optimal 
% force = 1 Nm).  The torque generators have activation dynamics.
% 
% Muscle activation dynamics time constants were determined as functions of
% muscle mass and fiber type (Winters & Stark, 1985) using average lower
% limb fast-twitch fiber fractions from Miller (2018).  Fiber type data for
% the lumbar muscle were referenced from H�ggmark & Thorstensson (1979) and
% Rantanen et al. (1994).
%
% The joints are softly constrained to anatomical ranges of motion using 
% <ExpressionBasedCoordinateForce> representing joint stiffness from 
% ligaments and articular contact.  The expressions for the lower limb
% joints are double-exponents referenced from Clay Anderson's dissertation
% (Anderson, 1999) except for the toe joints, which has a linear function.
% The expressions for the upper limb are double-exponents with parameters
% that seemed to define reasonable ranges of motion.
%
% The optimal control problem is solved on a temporal grid of 50 intervals,
% which results in a solution on 101 nodes (i.e. one node every 1% of the
% stride cycle) with Hermite-Simpson collocation.
%
% After an optimization converges, the resulting kinematics and GRF are 
% plotted against the tracking targets, the muscle excitations and forces 
% are plotted against normative EMG on/off timing data from Sutherland 
% (2001), and the gross metabolic cost is calculated from the muscle stats
% using the model of Koelewijn et al. (2018), which is a smoothed version
% of the Umberger et al. (2003) model of human muscle energy expenditure.
% The gross metabolic cost calculation assumes a basal metabolic rate of 
% 1.0 W/kg body mass, including the model's basal heat rate of 1.0 W/kg 
% muscle mass.
%
% Author: Ross Miller (rosshm@umd.edu)
% Updated: November 11, 2020
%
%%% PERFORMANCE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This model and code are designed for use with Moco 0.4.0 and OpenSim 4.1.
% Moco's <DeGrooteFregly2016Muscle> model is not currently supported in the 
% OpenSim GUI and will need to be replaced with another muscle model tag to 
% visualize the model's muscles in the OpenSim application's GUI.
%
% Starting from the initial guess provided and running this code as-is, the
% optimization converged after 100 iterations and 148 minutes of wall-time
% on a MacBook Pro (16-inch, 2019) with a 2.6 GHz 6-core Intel Core i7 CPU 
% and 64 GB of memory.  Changes to the cost function or model's parameters 
% will likely require more iterations for convergence but the iterations 
% per hour should be similar.  Using denser collocation grids or increasing 
% the model's complexity (more states, more controls) will decrease the
% iterations per hour.  A slightly more powerful desktop computer (iMac, 
% Retina 5K, 27-inch, 2020) with a 3.6 GHz 10-core Intel Core i9 CPU and 64 
% GB of memory performed about twice as many iterations per hour.
% 
%%% KNOWN ISSUES AND LIMITATIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% (1) I've not been able to get good results with implicit multibody
% dynamics.  Usually the optimization will not converge.
%
% (2) This code occasionally crashes Matlab in the midst of an IPOPT run.  
% I suspect they may be a Mac-or machine-specific issue.  The crashes are 
% not reproducible, i.e. running the same code with the same settings and 
% inputs on the same machine does not crash again.
%
% (3) In predictive simulations the GRF are sometimes "spiky" (signal power
% at unrealistically high frequencies).
%
% (4) Trunk angular velocities are not tracked.  I keep meaning to add a
% MocoAngularVelocityTrackingGoal for this.
%
%%% REFERENCES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
% Anderson DE, Madigan ML, Nussbaum MA (2007).  Maximum voluntary joint 
% torque as a function of joint angle and angular velocity: model 
% development and application to the lower limb.  Journal of Biomechanics
% 40, 3105-3113.
%
% Anderson FC (1999).  A dynamic optimization solution for a complete cycle
% of normal gait.  Doctoral dissertation, University of Texas at Austin.
%
% Collins SH, Adamczyk PG, Kuo AD (2009).  Dynamic arm swinging in human
% walking.  Proceedings of the Royal Society B 276, 3679-3688.
%
% H�ggmark T, Thorstensson A (1979).  Fibre types in human abdominal
% muscles.  Acta Physiologica Scandinavica 107, 319-325.
%
% Hasson CJ, Miller RH, Caldwell GE (2011).  Contractile and elastic ankle
% joint muscular properties in young and older adults.  PLoS One 6, article
% e15953.
%
% Keller TS, Roy AL (2002).  Posture-dependent isometric trunk extension
% and flexion strength in normal male and female subjects.  Journal of
% Spinal Disorders & Techniques 15, 312-318.
%
% Koelewijn AD, Dorschky E, van den Bogart AJ (2018).  A metabolic energy 
% expenditure model with a continuous first derivative and its application 
% to predictive simulations of gait.  Computer Methods in Biomechanics &
% Biomedical Engineering 21, 521-531.
%
% Kura H, Luo ZP, Kitaoka HB, An KN (1997).  Quantitative analysis of the
% intrinsic muscles of the foot.  Anatomical Record 249, 143-151.
%
% Miller RH (2018).  Hill-based muscle modeling.  In: M�ller B, Wolf SI
% (eds.), Handbook of Human Motion, 373-394.  Berlin: Springer.
%
% Miller RH, Edwards WB, Brandon SCE, Morton AM, Deluzio KJ (2014).  Why 
% don't most runners get knee osteoarthritis? A case for per-unit-distance 
% loads.  Medicine & Science in Sports & Exercise 46, 572-579.  
%
% Raabe ME, Chaudhari AMW (2016).  An investigation of jogging biomechanics 
% using the full-body lumbar spine model: model development and validation.
% Journal of Biomechanics 49, 1238-1243.
%
% Rajagopal A, Dembia CL, DeMers MS, Delp DD, Hicks JL, Delp SL (2016).
% Full-body musculoskeletal model for muscle-driven simulation of human
% gait.  IEEE Transactions on Biomedical Engineering 63, 2068-2079.
%
% Rantanen J, Rissanen A, Kalimo H (1994).  Lumbar muscle fiber size and 
% type distribution in normal subjects.  European Spine Journal 3, 331-335.
%
% Sutherland DH (2001).  The evoluation of clinical gait analysis part 1:
% kinesiological EMG.  Gait & Posture 14, 61-70.
%
% Umberger BR, Gerritsen KGM, Martin PE (2003).  A model of human muscle
% energy expenditure.  Computer Methods in Biomechanics & Biomedical
% Engineering 6, 99-111.
%
% Winters JM, Stark L (1985).  Analysis of fundamental human movement
% patterns through the use of in-depth antagonistic muscle models.  IEEE
% Transactions on Biomedical Engineering 32, 826-839.
%
%%% FUNDING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Funding for this project was provided by the Army Advanced Medical
% Technology Initiative, administered via Henry M. Jackson Foundation 
% (contract #978111, "An Advanced Biomechanical Model to Guide Prosthetic 
% Prescription and Rehabilitation After Amputation").
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
clear
close all
clc

% Load Moco libraries
import org.opensim.modeling.*;

% Options and settings
SolveTrackingProblem = 1; % Set to 1 to run an optimization
AvgSpeed = 1.45;          % Average walking speed in speed constraint (m/s)
w = 50.0/95;              % Weight on control effort term in cost function; 95 is the number of controls

% Define the motion tracking problem
track = MocoTrack();
track.setName('gaitTracking');
tableStatesProcessor = TableProcessor('refQ_31DoF.sto');                 % Target kinematic states for tracking
tableStatesProcessor.append(TabOpLowPassFilter(10));                     % Smooth the target kinematic data (helpful for shoulder and elbow angles, which were manually digitized)
modelProcessor = ModelProcessor('model_31d84m.osim');                    % Load the OpenSim model
modelProcessor.append(ModOpTendonComplianceDynamicsModeDGF('implicit')); % Use muscle contractile dynamics
%modelProcessor.append(ModOpIgnorePassiveFiberForcesDGF());              % Set passive muscle fiber forces to zero
track.setModel(modelProcessor);                                          % Apply the model to the tracking problem
track.setStatesReference(tableStatesProcessor);                          % Apply the target state data to the tracking problem
track.set_states_global_tracking_weight(1.0);                            % Default tracking weight (is changed below)
track.set_allow_unused_references(false);                                % Target data can include DoF not in this model
track.set_track_reference_position_derivatives(true);                    % Track speed trajectories
track.set_apply_tracked_states_to_guess(true);                           % Use target data if generating a new initial guess
track.set_initial_time(0.0);                                             % Initial time [s]
track.set_final_time(1.00);                                              % Final time [s], comment out to optimize movement duration

% Specify tracking weights as standard deviations averaged over the gait cycle from Miller et al. (2014)
pq = 1.0/37; % Divided by 37 because there are 37 tracking targets: 28 DoF, 3 trunk angles, 6 GRF components
stateWeights = MocoWeightSet();
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tx/value',       pq/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_ty/value',       pq/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tz/value',       pq/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tilt/value',     pq/(1*0.0585)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_list/value',     pq/(1*0.0254)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_rotation/value', pq/(1*0.0474)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_ext/value',            0/(1*0.1745)^2)); % Global trunk posture is tracking in another goal
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_bend/value',           0/(1*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_rota/value',           0/(1*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_flexion_r/value',          pq/(1*0.0647)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_adduction_r/value',        pq/(1*0.0410)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_rotation_r/value',         pq/(3*0.0728)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/knee_r/knee_angle_r/value',          pq/(1*0.0889)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/ankle_r/ankle_angle_r/value',        pq/(1*0.0574)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/subtalar_r/subtalar_angle_r/value',  pq/(3*0.0595)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/mtp_r/mtp_angle_r/value',            pq/(3*0.0873)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_flexion_r/value',pq/(1*0.0989)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_adduction_r/value',pq/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_rotation_r/value',pq/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/elbow_r/elbow_flexion_r/value',      pq/(1*0.0915)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_flexion_l/value',          pq/(1*0.0647)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_adduction_l/value',        pq/(1*0.0410)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_rotation_l/value',         pq/(3*0.0728)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/knee_l/knee_angle_l/value',          pq/(1*0.0889)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/ankle_l/ankle_angle_l/value',        pq/(1*0.0574)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/subtalar_l/subtalar_angle_l/value',  pq/(3*0.0595)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/mtp_l/mtp_angle_l/value',            pq/(3*0.0873)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_flexion_l/value',pq/(1*0.0989)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_adduction_l/value',pq/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_rotation_l/value',pq/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/elbow_l/elbow_flexion_l/value',      pq/(1*0.0915)^2));
pw = pq*0.0001; % Scale the generalized speed tracking errors by this constant
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tx/speed',       pw/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_ty/speed',       pw/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tz/speed',       pw/(3*0.1000)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_tilt/speed',     pw/(1*0.0585)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_list/speed',     pw/(1*0.0254)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/groundPelvis/pelvis_rotation/speed', pw/(1*0.0474)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_ext/speed',            0/(1*0.1745)^2)); % Trunk velocities are not tracked;
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_bend/speed',           0/(1*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/lumbar/lumbar_rota/speed',           0/(1*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_flexion_r/speed',          pw/(1*0.0647)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_adduction_r/speed',        pw/(1*0.0410)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_r/hip_rotation_r/speed',         pw/(3*0.0728)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/knee_r/knee_angle_r/speed',          pw/(1*0.0889)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/ankle_r/ankle_angle_r/speed',        pw/(1*0.0574)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/subtalar_r/subtalar_angle_r/speed',  pw/(3*0.0595)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/mtp_r/mtp_angle_r/speed',            pw/(3*0.0873)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_flexion_r/speed',pw/(1*0.0989)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_adduction_r/speed',pw/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_r/shoulder_rotation_r/speed',pw/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/elbow_r/elbow_flexion_r/speed',      pw/(1*0.0915)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_flexion_l/speed',          pw/(1*0.0647)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_adduction_l/speed',        pw/(1*0.0410)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/hip_l/hip_rotation_l/speed',         pw/(3*0.0728)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/knee_l/knee_angle_l/speed',          pw/(1*0.0889)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/ankle_l/ankle_angle_l/speed',        pw/(1*0.0574)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/subtalar_l/subtalar_angle_l/speed',  pw/(3*0.0595)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/mtp_l/mtp_angle_l/speed',            pw/(3*0.0873)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_flexion_l/speed',pw/(1*0.0989)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_adduction_l/speed',pw/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/shoulder_l/shoulder_rotation_l/speed',pw/(2*0.1745)^2));
stateWeights.cloneAndAppend(MocoWeight('/jointset/elbow_l/elbow_flexion_l/speed',      pw/(1*0.0915)^2));
track.set_states_weight_set(stateWeights);

% Define the Moco study and problem
study = track.initialize();
problem = study.updProblem();

% Define the periodicity goal
periodicityGoal = MocoPeriodicityGoal('symmetryGoal');
problem.addGoal(periodicityGoal);
model = modelProcessor.process();
model.initSystem();

% All states are periodic except pelvis anterior-posterior translation
for i = 1:model.getNumStateVariables()
    currentStateName = string(model.getStateVariableNames().getitem(i-1));
    if (~contains(currentStateName,'pelvis_tx/value'))
       periodicityGoal.addStatePair(MocoPeriodicityGoalPair(currentStateName));
    end
end

% All controls are periodic
for i = 1:model.getNumControls()
    currentControlName = string(problem.createRep().createControlInfoNames().get(i-1));
    periodicityGoal.addControlPair(MocoPeriodicityGoalPair(currentControlName));
end

% Prescribed average walking speed
speedGoal = MocoAverageSpeedGoal('speed');
speedGoal.set_desired_average_speed(AvgSpeed);
problem.addGoal(speedGoal);

% Prevent body penetration
distanceConstraint = MocoFrameDistanceConstraint();
distanceConstraint.setName('distance_constraint');
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/calcn_l','/bodyset/calcn_r',0.10,100));
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/toes_l', '/bodyset/toes_r', 0.10,100));
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/calcn_l','/bodyset/toes_r', 0.10,100));
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/toes_l', '/bodyset/calcn_r',0.10,100));
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/hand_l', '/bodyset/pelvis', 0.20,100));
distanceConstraint.addFramePair(MocoFrameDistanceConstraintPair('/bodyset/hand_r', '/bodyset/pelvis', 0.20,100));
problem.addPathConstraint(distanceConstraint);

% Define upright torso goal
torsoGoal = MocoOrientationTrackingGoal('torsoGoal',(3/(0.0873^2))/37);
torsoTable = TableProcessor('refQ_torso_31d84m.sto');
torsoGoal.setStatesReference(torsoTable);
paths = StdVectorString();
paths.add('/bodyset/torso')
torsoGoal.setFramePaths(paths);
problem.addGoal(torsoGoal);

% Control effort term (minimize squared muscle excitations)
effort = MocoControlGoal.safeDownCast(problem.updGoal('control_effort'));
effort.setWeight(w);
effort.setExponent(2);
effort.setDivideByDisplacement(false);

% GRF tracking
contactTracking = MocoContactTrackingGoal('contact',6/(75.337*9.81)/(0.1073^2)/37);
contactTracking.setExternalLoadsFile('refGRF_3D.xml');
forceNamesRightFoot = StdVectorString();
forceNamesRightFoot.add('/forceset/contactHeel_r');
forceNamesRightFoot.add('/forceset/contactMH1_r');
forceNamesRightFoot.add('/forceset/contactMH3_r');
forceNamesRightFoot.add('/forceset/contactMH5_r');
forceNamesRightFoot.add('/forceset/contactOtherToes_r');
forceNamesRightFoot.add('/forceset/contactHallux_r');
trackRightGRF = MocoContactTrackingGoalGroup(forceNamesRightFoot,'RightGRF');
trackRightGRF.append_alternative_frame_paths('/bodyset/toes_r');
contactTracking.addContactGroup(trackRightGRF);
forceNamesLeftFoot = StdVectorString();
forceNamesLeftFoot.add('/forceset/contactHeel_l');
forceNamesLeftFoot.add('/forceset/contactMH1_l');
forceNamesLeftFoot.add('/forceset/contactMH3_l');
forceNamesLeftFoot.add('/forceset/contactMH5_l');
forceNamesLeftFoot.add('/forceset/contactOtherToes_l');
forceNamesLeftFoot.add('/forceset/contactHallux_l');
trackLeftGRF = MocoContactTrackingGoalGroup(forceNamesLeftFoot,'LeftGRF');
trackLeftGRF.append_alternative_frame_paths('/bodyset/toes_l');
contactTracking.addContactGroup(trackLeftGRF);
problem.addGoal(contactTracking);

% Bound constraints
%problem.setTimeBounds(0, [0.95, 1.05]); % Uncomment if optimizing movement duration
problem.setStateInfo('/jointset/groundPelvis/pelvis_tilt/value', [-10*pi/180, 10*pi/180]);
problem.setStateInfo('/jointset/groundPelvis/pelvis_list/value', [-10*pi/180, 10*pi/180]);
problem.setStateInfo('/jointset/groundPelvis/pelvis_rotation/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/groundPelvis/pelvis_tx/value', [-0.2, 2]);
problem.setStateInfo('/jointset/groundPelvis/pelvis_ty/value', [0.75, 1.25]);
problem.setStateInfo('/jointset/groundPelvis/pelvis_tz/value', [-0.25, 0.25]);
problem.setStateInfo('/jointset/hip_l/hip_flexion_l/value', [-25*pi/180, 45*pi/180]);
problem.setStateInfo('/jointset/hip_l/hip_adduction_l/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/hip_l/hip_rotation_l/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/hip_r/hip_flexion_r/value', [-25*pi/180, 45*pi/180]);
problem.setStateInfo('/jointset/hip_r/hip_adduction_r/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/hip_r/hip_rotation_r/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/knee_l/knee_angle_l/value', [-75*pi/180, 0]);
problem.setStateInfo('/jointset/knee_r/knee_angle_r/value', [-75*pi/180, 0]);
problem.setStateInfo('/jointset/ankle_l/ankle_angle_l/value', [-30*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/ankle_r/ankle_angle_r/value', [-30*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/subtalar_l/subtalar_angle_l/value', [-20*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/subtalar_r/subtalar_angle_r/value', [-20*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/mtp_l/mtp_angle_l/value', [-20*pi/180, 70*pi/180]);
problem.setStateInfo('/jointset/mtp_r/mtp_angle_r/value', [-20*pi/180, 70*pi/180]);
problem.setStateInfo('/jointset/lumbar/lumbar_ext/value', [-20*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/lumbar/lumbar_bend/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/lumbar/lumbar_rota/value', [-15*pi/180, 15*pi/180]);
problem.setStateInfo('/jointset/shoulder_r/shoulder_flexion_r/value', [-40*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/shoulder_r/shoulder_adduction_r/value', [-20*pi/180, 10*pi/180]);
problem.setStateInfo('/jointset/shoulder_r/shoulder_rotation_r/value', [-20*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/shoulder_l/shoulder_flexion_l/value', [-40*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/shoulder_l/shoulder_adduction_l/value', [-20*pi/180, 10*pi/180]);
problem.setStateInfo('/jointset/shoulder_l/shoulder_rotation_l/value', [-20*pi/180, 20*pi/180]);
problem.setStateInfo('/jointset/elbow_r/elbow_flexion_r/value', [10*pi/180, 70*pi/180]);
problem.setStateInfo('/jointset/elbow_l/elbow_flexion_l/value', [10*pi/180, 70*pi/180]);

problem.setStateInfoPattern('/forceset/.*/normalized_tendon_force', [0, 1.8], [], []);
problem.setStateInfoPattern('/forceset/.*/activation',   [0.001, 1.0], [], []);
problem.setStateInfoPattern('/forceset/lumbar_extAct/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/lumbar_bendAct/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/lumbar_rotaAct/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_flexionAct_r/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_adductionAct_r/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_rotationAct_r/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/elbow_flexionAct_r/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_flexionAct_l/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_adductionAct_l/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/shoulder_rotationAct_l/activation',   [-1.0, 1.0], [], []);
problem.setStateInfoPattern('/forceset/elbow_flexionAct_l/activation',   [-1.0, 1.0], [], []);


% Define the solver and set its options
solver = MocoCasADiSolver.safeDownCast(study.updSolver());
%solver.set_multibody_dynamics_mode('implicit')
%solver.set_minimize_implicit_multibody_accelerations(true)
%solver.set_implicit_multibody_accelerations_weight(0.000001)
solver.set_optim_max_iterations(2000);
solver.set_num_mesh_intervals(50);
solver.set_optim_constraint_tolerance(1e-04);
solver.set_optim_convergence_tolerance(1e+01);
solver.set_minimize_implicit_auxiliary_derivatives(true)
solver.set_implicit_auxiliary_derivatives_weight(0.00001)
solver.set_enforce_constraint_derivatives(true)
%solver.set_lagrange_multiplier_weight(100.0);
solver.resetProblem(problem);

% Set the normalized tendon forces if not loading initial guess from file
% guess = solver.createGuess();
% numRows = guess.getNumTimes();
% StateNames = model.getStateVariableNames();
% for i = 1:model.getNumStateVariables()
%     currentStateName = string(StateNames.getitem(i-1));
%     if contains(currentStateName,'normalized_tendon_force')
%         MusName = currentStateName;
%         guess.setState(currentStateName, linspace(0.2,0.2,numRows));
%     end
% end
  
% Uncomment this line if not loading an initial guess
%solver.setGuess(guess);

% Load the initial guess from this file
solver.setGuessFile('soln_track_N50_w50.sto');

% Insert previous solution from a less complex model
% guess = solver.createGuess();
% prevSolution = MocoTrajectory('soln_track_N5.sto');
% prevStatesTable = prevSolution.exportToStatesTable();
% prevControlsTable = prevSolution.exportToControlsTable();
% guess.insertStatesTrajectory(prevStatesTable, true);
% guess.insertControlsTrajectory(prevControlsTable, true);
% solver.setGuess(guess);

% Solve the problem
if (SolveTrackingProblem == 1)
    gaitTrackingSolution = study.solve();
    
    % Write the solution to a file
    gaitTrackingSolution.write('name_the_output_file_here.sto');
    
    % Write solution's GRF to a file
    contact_r = StdVectorString();
    contact_l = StdVectorString();
    contact_r.add('/forceset/contactHeel_r');
    contact_r.add('/forceset/contactMH1_r');
    contact_r.add('/forceset/contactMH3_r');
    contact_r.add('/forceset/contactMH5_r');
    contact_r.add('/forceset/contactOtherToes_r');
    contact_r.add('/forceset/contactHallux_r');
    contact_l.add('/forceset/contactHeel_l');
    contact_l.add('/forceset/contactMH1_l');
    contact_l.add('/forceset/contactMH3_l');
    contact_l.add('/forceset/contactMH5_l');
    contact_l.add('/forceset/contactOtherToes_l');
    contact_l.add('/forceset/contactHallux_l');
    externalForcesTableFlat = opensimMoco.createExternalLoadsTableForGait(model,gaitTrackingSolution,contact_r,contact_l);
    opensimMoco.writeTableToFile(externalForcesTableFlat,'name_the_output_file_here_GRF.sto');
else
    return
end

% Plot solution and target data
temp1 = importdata('name_the_output_file_here_GRF.sto');
SimGRF = temp1.data;
temp2 = importdata('name_the_output_file_here.sto');
SimX = temp2.data;
temp3 = importdata('refGRF_3D.sto');
TarGRF = temp3.data;
temp4 = importdata('gaitTracking_tracked_states.sto');
TarX = temp4.data;

SimX_colheaders = temp2.colheaders;
j = 1;
for i = 1:length(SimX_colheaders)
    currentVarName = string(SimX_colheaders(i));
    if endsWith(currentVarName,'_r/normalized_tendon_force')
        ivec(j) = i;
        j = j + 1;
    end
end
MusForces = SimX(:,ivec);
MusExcitations = SimX(:,247:330);

% Muscle names for plotting
MusNames = [{'addbrev'},{'addlong'},{'addmag'},{'bflh'},{'bfsh'},{'edl'}, ...
            {'ehl'},{'ercspn'},{'extobl'},{'fdb'},{'fdl'},{'fhl'}, ...
            {'gaslat'},{'gasmed'},{'glmax'},{'glmed'},{'glmin'},{'grac'}, ...
            {'iliacus'},{'intobl'},{'obtext'},{'pect'},{'perbrev'},{'perlong'}, ...
            {'pertert'},{'piri'},{'popli'},{'psoas'},{'quadfem'}, ...
            {'recabd'},{'recfem'},{'sart'},{'semimem'},{'semiten'}, ...
            {'soleus'},{'tfl'},{'tibant'},{'tibpost'},{'tricox'}, ...
            {'vasint'},{'vaslat'},{'vasmed'}];

% Normative indwelling EMG on/off timing from Sutherland (2001)
MusEMG.psoas = [57.6,71.2];
MusEMG.iliacus = [62.4 80.0];
MusEMG.sart = [62.4 77.6];
MusEMG.addlong = [41.0 62.4];
MusEMG.addbrev = [48.8 62.7];
MusEMG.addmag = [44.7 62.4];
MusEMG.tfl = [11.5 43.1];
MusEMG.gaslat = [14.2 50.5];
MusEMG.gasmed = [14.2 50.5];
MusEMG.soleus = [11.5 47.1];
MusEMG.fdl = [18.0 50.8];
MusEMG.fhl = [21.7 49.5];
MusEMG.tibpost = [5.4 52.9];
MusEMG.perlong = [9.5 53.2];
MusEMG.perbrev = [19.7 49.8];
MusEMG.grac = [0 5.4 79.7 100];
MusEMG.recfem = [0 11.2 46.8 70.2 91.9 100];
MusEMG.vasint = [0 27.8 55.6 63.1 86.8 100];
MusEMG.vaslat = [0 22.4 88.5 100];
MusEMG.vasmed = [0 24.4 86.4 100];
MusEMG.glmax = [0 14.2 94.6 100];
MusEMG.semiten = [0 7.1 84.4 100];
MusEMG.semimem = [0 6.1 84.7 100];
MusEMG.glmed = [0 40.0 87.8 100];
MusEMG.glmin = [0 39.3];
MusEMG.bflh = [0 9.5 88.1 100];
MusEMG.bfsh = [0 4.1 79.3 100];
MusEMG.tibant = [0 14.2 55.9 100];
MusEMG.edl = [0 13.9 49.5 100];
MusEMG.ehl = [0 16.9 54.9 100];
MusEMG.popli = [0 54.9 90.2 100];

% Kinematics and GRF (for brevity only the right-side data are plotted)
figure()
subplot(2,3,1)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,2)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,2)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF AP (%BW)','FontWeight','b')
    legend('Simulation','Target')
    ylim([-30 30])
subplot(2,3,2)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,3)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,3)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF VE (%BW)','FontWeight','b')
    ylim([-10 150])
subplot(2,3,3)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,4)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,4)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF ML (%BW)','FontWeight','b')
    ylim([-10 10])
subplot(2,3,4)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,8)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,5)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF AP (%BW)','FontWeight','b')
    legend('Simulation','Target')
    ylim([-30 30])
subplot(2,3,5)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,9)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,6)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF VE (%BW)','FontWeight','b')
    ylim([-10 150])
subplot(2,3,6)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,10)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,7)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF ML (%BW)','FontWeight','b')
    ylim([-10 10])

figure()
subplot(4,6,1)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,2)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,2)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF AP (%BW)','FontWeight','b')
    legend('Simulation','Target')
    ylim([-30 30])
subplot(4,6,2)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,3)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,3)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF VE (%BW)','FontWeight','b')
    ylim([-10 150])
subplot(4,6,3)
    hold on; box on;
    plot(SimGRF(:,1)/SimGRF(end,1)*100,SimGRF(:,4)/(75.337*9.81)*100,'-','LineWidth',2)
    plot(TarGRF(:,1)/TarGRF(end,1)*100,TarGRF(:,4)/(75.337*9.81)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('GRF ML (%BW)','FontWeight','b')
    ylim([-10 10])
    
subplot(4,6,4)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,5)*100,'-','LineWidth',2)
    plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,2)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis AP (cm)','FontWeight','b')
    ylim([0 150])
subplot(4,6,5)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,6)*100,'-','LineWidth',2)
    plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,3)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis VE (cm)','FontWeight','b') 
    ylim([88 94])
subplot(4,6,6)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,7)*100,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,14)*100,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis ML (cm)','FontWeight','b')
    ylim([-4 4])
    
subplot(4,6,7)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,2)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,4)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis Tilt (deg)','FontWeight','b')
    ylim([-10 10])
subplot(4,6,8)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,3)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,15)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis List (deg)','FontWeight','b')
    ylim([-10 10])
subplot(4,6,9)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,4)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,16)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Pelvis Rotation (deg)','FontWeight','b')
    ylim([-10 10])
    
subplot(4,6,10)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,14)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,5)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Lumbar Extension (deg)','FontWeight','b')
    ylim([-10 10])
subplot(4,6,11)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,15)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,17)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Lumbar Bending (deg)','FontWeight','b') 
    ylim([-10 10])
subplot(4,6,12)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,16)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,18)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Lumbar Rotation (deg)','FontWeight','b')
    ylim([-10 10])
    
subplot(4,6,13)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,11)*180/pi,'-','LineWidth',2)
    plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,6)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Hip Flexion (deg)','FontWeight','b')
    ylim([-20 40])
subplot(4,6,14)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,12)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,19)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Hip Adduction (deg)','FontWeight','b') 
    ylim([-10 10])
subplot(4,6,15)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,13)*180/pi,'-','LineWidth',2)
    plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,20)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Hip Rotation (deg)','FontWeight','b')
    ylim([-10 10])
    
subplot(4,6,16)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,20)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,7)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Knee Extension (deg)','FontWeight','b')
    ylim([-80 20])
    
subplot(4,6,17)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,28)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,8)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Ankle Dorsiflexion (deg)','FontWeight','b')
    ylim([-20 20])
subplot(4,6,18)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,32)*180/pi,'-','LineWidth',2)
    plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,21)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Subtalar Inversion (deg)','FontWeight','b')
    ylim([-20 20])
subplot(4,6,19)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,34)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,9)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Toe Extension (deg)','FontWeight','b')
    ylim([-20 60])
    
subplot(4,6,20)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,21)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,25)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Shoulder Flexion (deg)','FontWeight','b')
    ylim([-30 10])
subplot(4,6,21)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,22)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,29)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Shoulder Adduction (deg)','FontWeight','b')
    ylim([-10 10])
subplot(4,6,22)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,23)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,30)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Shoulder Rotation (deg)','FontWeight','b')
    ylim([-10 10])
subplot(4,6,23)
    hold on; box on;
    plot(SimX(:,1)/SimX(end,1)*100,SimX(:,29)*180/pi,'-','LineWidth',2)
	plot(TarX(51:151,1)/TarX(151,1)*100,TarX(51:151,26)*180/pi,':','LineWidth',2)
    xlabel('Stride (%)','FontWeight','b')
    ylabel('Elbow Flexion (deg)','FontWeight','b')
    ylim([20 60])

% Muscle excitations (for brevity only the right-side muscles are plotted)
figure()
for i = 1:42
    subplot(6,7,i)
        hold on; box on;
        h1=plot(SimX(:,1)/SimX(end,1)*100,MusForces(:,i),'r-','LineWidth',2);
        h2=plot(SimX(:,1)/SimX(end,1)*100,SimX(:,246+i),'k:','LineWidth',2);
        xlim([0 100])
        ylim([-0.2 1.2])
        set(gca,'YTick',[0 1])
        ylabel(MusNames(i),'FontWeight','b')
        if (i > 35)
            xlabel('Stride (%)','FontWeight','b')
            set(gca,'XTick',0:20:100)
        else
            set(gca,'XTick',0:20:100)
            set(gca,'XTickLabel',[])
        end
        
        % Muscle EMG on/off timing (Sutherland, 2001)
        if any(strcmp(string(fieldnames(MusEMG)),string(MusNames(i))))
            if (length(MusEMG.(string(MusNames(i)))) == 2)
                h3=plot(MusEMG.(string(MusNames(i))),[-0.1 -0.1],'k-','LineWidth',3);
            elseif (length(MusEMG.(string(MusNames(i)))) == 4)
                plot(MusEMG.(string(MusNames(i)))(1:2),[-0.1 -0.1],'k-','LineWidth',3)
                plot(MusEMG.(string(MusNames(i)))(3:4),[-0.1 -0.1],'k-','LineWidth',3)
            elseif (length(MusEMG.(string(MusNames(i)))) == 6)
                plot(MusEMG.(string(MusNames(i)))(1:2),[-0.1 -0.1],'k-','LineWidth',3)
                plot(MusEMG.(string(MusNames(i)))(3:4),[-0.1 -0.1],'k-','LineWidth',3)
                plot(MusEMG.(string(MusNames(i)))(5:6),[-0.1 -0.1],'k-','LineWidth',3)
            end
        end
        
        if (i == 1)
            legend([h1 h2 h3],'SEC force','CC excitation','EMG timing')
        end
end

% Coordinate actuators
ACANames = [{'Lumbar Extension'},{'Lumbar Bending'},{'Lumbar Rotation'}, ...
            {'Shoulder Flexion'},{'Shoulder Adduction'},{'Shoulder Rotation'}, ...
            {'Elbow Flexion'}];
ActACA = SimX(:,236:242);
uACA = SimX(:,331:337);
figure()
for i = 1:7
    subplot(3,3,i)
        hold on; box on;
        h1=plot(SimX(:,1)/SimX(end,1)*100,ActACA(:,i),'r-','LineWidth',2);
        h2=plot(SimX(:,1)/SimX(end,1)*100,uACA(:,i),'k:','LineWidth',2);
        xlim([0 100])
        ylim([-1.2 1.2])
        set(gca,'YTick',[-1 0 1])
        ylabel(ACANames(i),'FontWeight','b')
        set(gca,'XTick',0:20:100)
        xlabel('Stride (%)','FontWeight','b')
end

% Muscle energy expenditure (Umberger et al., 2003; Koelewijn et al., 2018)
outputPaths = StdVectorString();
outputPaths.add('.*fiber_velocity');
outputPaths.add('.*activation');
outputPaths.add('.*active_fiber_force');
outputPaths.add('.*fiber_length');
outputPaths.add('.*active_force_length_multiplier');
outputTable = study.analyze(gaitTrackingSolution, outputPaths);
opensimMoco.writeTableToFile(outputTable,'MusOut.sto')
temp5 = importdata('MusOut.sto');
MusOut = temp5.data;
MusOutHeaders = temp5.colheaders;

j = 1;
for i = 1:length(MusOutHeaders)
    currentVarName = string(MusOutHeaders(i));
    if endsWith(currentVarName,'activation')
        ivec(j) = i;
        j = j + 1;
    end
end
MusActivations = MusOut(:,ivec);

j = 1;
for i = 1:length(MusOutHeaders)
    currentVarName = string(MusOutHeaders(i));
    if endsWith(currentVarName,'|fiber_velocity')
        ivec(j) = i;
        j = j + 1;
    end
end
MusFiberVelocities = MusOut(:,ivec);

j = 1;
for i = 1:length(MusOutHeaders)
    currentVarName = string(MusOutHeaders(i));
    if endsWith(currentVarName,'|active_fiber_force')
        ivec(j) = i;
        j = j + 1;
    end
end
MusActiveFiberForces = MusOut(:,ivec);

j = 1;
for i = 1:length(MusOutHeaders)
    currentVarName = string(MusOutHeaders(i));
    if endsWith(currentVarName,'|fiber_length')
        ivec(j) = i;
        j = j + 1;
    end
end
MusFiberLengths = MusOut(:,ivec);

j = 1;
for i = 1:length(MusOutHeaders)
    currentVarName = string(MusOutHeaders(i));
    if endsWith(currentVarName,'|active_force_length_multiplier')
        ivec(j) = i;
        j = j + 1;
    end
end
MusActiveForceLengthMultipliers = MusOut(:,ivec);
    
BodyMass = model.getTotalMass(model.initSystem()); % Total body mass (kg)
BasalMetabolicRate = 0.728; % W/kg, excepting the contribution from muscles which is 0.272 W/kg and is accounted for below
STEN = 62*100^2; % CC specific tension (N/m^2)
DEN = 1059.7;    % CC density (kg/m^3)
muscles = model.getMuscles;
for i = 1:84
    mus = muscles.get(i-1);
    Fo(i) = mus.get_max_isometric_force;   % Max isometric forces (N)
    Lo(i) = mus.get_optimal_fiber_length;  % CC optimal lengths (m)
end
Vmax = mus.get_max_contraction_velocity;   % CC maximum shortening velocity (Lo/s)

FT = [0.306; % Fast-twitch fiber fractions; these have to be entered manually for each muscle, they are not a specified parameter in <DeGrooteFregly2016Muscle>.  They could be backed out of the activation time constants but I can't figure out how to access those from Muscle objects.
0.383;
0.368;
0.393;
0.453;
0.451;
0.170;
0.385;
0.500;
0.500;
0.454;
0.457;
0.441;
0.441;
0.362;
0.140;
0.362;
0.345;
0.371;
0.500;
0.311;
0.368;
0.375;
0.375;
0.375;
0.157;
0.109;
0.415;
0.075;
0.450;
0.566;
0.415;
0.361;
0.485;
0.232;
0.372;
0.218;
0.200;
0.327;
0.452;
0.548;
0.480;
0.306;
0.383;
0.368;
0.393;
0.453;
0.451;
0.170;
0.385;
0.500;
0.500;
0.454;
0.457;
0.441;
0.441;
0.362;
0.140;
0.362;
0.345;
0.371;
0.500;
0.311;
0.368;
0.375;
0.375;
0.375;
0.157;
0.109;
0.415;
0.075;
0.450;
0.566;
0.415;
0.361;
0.485;
0.232;
0.372;
0.218;
0.200;
0.327;
0.452;
0.548;
0.480];

ST = 1 - FT;

aSST = 40/Vmax;
aSFT = 153/Vmax;
aL = 4.0*aSST;
S = 1.5;
        
for j = 1:size(MusOut,1)
    for i = 1:84
        Lcc = MusFiberLengths(j,i);
        vn = MusFiberVelocities(j,i)/Lo(i);
        vnS = 0.5*(vn - sqrt(vn^2 + 0.001^2));
        vnL = 0.5*(vn + sqrt(vn^2 + 0.001^2));
        Act = MusActivations(j,i);
        %u = MusExcitations(j,i);
        %A = u + 0.5*((Act - u)/2 + sqrt(((Act - u)/2)^2 + 0.001^2));
        A = Act;
        m = Fo(i)/STEN*Lo(i)*DEN;
        Wdot = -MusActiveFiberForces(j,i)*MusFiberVelocities(j,i);
        FL = MusActiveForceLengthMultipliers(j,i);
        AAM = A^0.6;
        ASL = A^2.0;
        if (Lcc < Lo(i))
            hAM = 128*FT(i) + 25;
            hSL = aL*vnL - aSST*vnS*ST(i) - aSFT*vnS*FT(i);
            if (-aSST*vnS > 100)
                hSL = aL*vnL - 100 - aSFT*vnS*FT(i);
            end
        else
            hAM = (128*FT(i) + 25)*(0.4 + 0.6*FL);
            hSL = FL*(aL*vnL - aSST*vnS*ST(i) - aSFT*vnS*FT(i));
            if (-aSST*vnS > 100)
                hSL = FL*(aL*vnL - 100 - aSFT*vnS*FT(i));
            end
        end
        Hdot = S*m*(hAM*AAM + hSL*ASL);
        if (Hdot < 1.0*m)
            Hdot = 1.0*m; % Muscle basal heat rate
        end
        if (vn <= 0)
            Edot = Hdot + Wdot;
        else
            Edot = Hdot + Wdot;
        end
        if (Edot < 1.0*m)
            Edot = 1.0*m; % Don't allow negative energy rates when work is negative
        end
        MusEnergyRate(j,i) = Edot;
        MusWorkRate(j,i) = Wdot;
        MusHeatRate(j,i) = Hdot;        
    end
    NetMetabolicRate(j) = sum(MusEnergyRate(j,:));
    NetWorkRate(j) = sum(MusWorkRate(j,:));
    NetHeatRate(j) = sum(MusHeatRate(j,:));
end

GrossMetabolicCost = (mean(NetMetabolicRate)/BodyMass + BasalMetabolicRate)/AvgSpeed

% Visualize the solution
study.visualize(gaitTrackingSolution);